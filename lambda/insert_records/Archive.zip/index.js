require('dotenv').config()
const { Client } = require('pg')

const config = {
  connectionString: process.env.CONNECTION_STRING,
  ssl: {
    rejectUnauthorized: false
  }
}

exports.handler = function(event, context, callback) {
  
  const client = new Client(config)
  client.connect(err => {
    if (err) {
      callback(err, null)
    } else {
      console.log('connected')
      client.query('SELECT NOW()', (err, res) => {
        if(err) callback(err, null)
        client.end()
        callback(null, res)

      })
    }
  })

};
